<?php
// ================================================================
//  AKTUÁLNA TAJNÁ ADRESA APPKY — prepísaná systémom automaticky.
//  Otvor tento súbor vo File Managery (v editore) a uvidíš ju tu.
//  Cez prehliadač je súbor prázdny — PHP sa vykoná, neunikne nič.
//
//  MESIAC: 2026-10  (platí 01.10.2026 – 31.10.2026)
//  ADRESA:  https://127.0.0.1:8123/?k=25F0F6F8FFF36C3F0108
//  ALEBO:   https://127.0.0.1:8123/25F0F6F8FFF36C3F0108
//
//  Ešte platný minulý kľúč (2026-09, do 30.09.2026): B17A8C91F0F3B88312C0
//
//  Posledná zmena: 29.10.2026 10:47:51
// ================================================================
return '25F0F6F8FFF36C3F0108';
