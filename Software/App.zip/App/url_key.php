<?php
// Tajny URL kluc appky — zdrojovy kod NIE JE verejne citatelny (PHP sa execuje).
// Tento subor patri vedla index.php na serveri. Nahrat cez File Manager.
return 'ggZM8kVQTdNHUe6frWqf3wHy';
