<?php
/**
 * SÚKROMNÁ KONFIGURÁCIA E-MAILOV — Elvosolar
 * ------------------------------------------------------------
 * Tento súbor sa NESMIE dostať na verejný web. .htaccess blokuje
 * všetky súbory začínajúce podtržníkom, takže zostáva len na serveri.
 * Necommitujte ho s vyplneným heslom alebo API kľúčom.
 *
 * PREDNOSŤ: premenné prostredia (Railway → Variables) majú vždy prednosť
 * pred hodnotami v tomto súbore. Súbor je preto len záloha pre klasický
 * hosting (Websupport), kde sa premenné nastavujú ťažšie.
 *
 *   RESEND_API_KEY   HTTPS API (Railway ho odporúča — SMTP je na Free/Hobby plánoch blokované)
 *   SMTP_HOST, SMTP_PORT, SMTP_SECURE, SMTP_USER, SMTP_PASS
 *   MAIL_FROM, MAIL_FROM_NAME, MAIL_TO, MAIL_BACKUP, MAIL_REPLY_TO, SITE_URL
 *
 * ODOSIELANIE (send.php skúša v tomto poradí, prvé funkčné vyhráva):
 *   1. Resend HTTPS API     — funguje všade, aj na Railway (odporúčané)
 *   2. Brevo HTTPS API      — voliteľná záloha
 *   3. SMTP s prihlásením   — klasický hosting, na Railway len Pro plán
 *   4. PHP mail()           — obmedzený hosting
 *   5. záložná adresa s predmetom [ZÁLOHA]
 *   6. _undelivered.log     — správa sa uloží na server, nič sa nestratí
 *
 * AKO ZAPNÚŤ ODESIELANIE:
 *   Railway:  Variables → RESEND_API_KEY=re_… , MAIL_FROM=info@elvosolar.sk
 *             a v Resende overiť doménu elvosolar.sk (SPF + DKIM záznamy).
 *   Websupport: nižšie vyplňte 'smtp_pass' heslom schránky info@elvosolar.sk.
 */

// Priama návšteva súboru v prehliadači → 404 (obsah sa nikdy nevypíše).
if (isset($_SERVER['SCRIPT_FILENAME']) && basename((string)$_SERVER['SCRIPT_FILENAME']) === basename(__FILE__)) {
    http_response_code(404);
    exit;
}

return [
    /* ---------- Resend (HTTPS API — hlavná cesta na Railway) ---------- */
    'resend_key'  => '',               // API kľúč z resend.com (začína "re_")

    /* ---------- SMTP (klasický hosting) ---------- */
    'smtp_host'   => 'smtp.m1.websupport.sk',
    'smtp_port'   => 465,
    'smtp_secure' => 'ssl',            // 'ssl' pre port 465, 'tls' pre 587, 'none' len pre lokálne testy
    'smtp_user'   => 'info@elvosolar.sk',
    'smtp_pass'   => '',               // <-- sem heslo schránky z WebAdminu

    /* ---------- Brevo (voliteľná záloha) ---------- */
    'brevo_key'   => '',               // API kľúč z Brevo (začína "xkeysib-"), môže zostať prázdny

    /* ---------- Adresy ---------- */
    // Overený odosielateľ na vlastnej doméne (nikdy nie gmail.com)
    'from_email'   => 'info@elvosolar.sk',
    'from_name'    => 'Elvosolar, a.s.',

    // Kam chodia dopyty z formulárov
    'to_email'     => 'info@elvosolar.sk',

    // Záloha: ak hlavná adresa zlyhá, správa ide sem (predmet dostane [ZÁLOHA]).
    // Ak zlyhá aj táto adresa, send.php uloží správu do _undelivered.log.
    'backup_email' => 'adam.dzurko5@gmail.com',

    // Odpovedať na tento e-mail (klientom sa zobrazí pri odpovedi)
    'reply_to'     => 'info@elvosolar.sk',

    // Adresa webu (použitá v šablónach e-mailov)
    'site_url'     => 'https://www.elvosolar.sk',
];
