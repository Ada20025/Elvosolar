<?php
declare(strict_types=1);
/**
 * web-router.php — front controller (čisté URL bez prípony .html)
 */

// ---------------- Trasy: URL cesta => súbor ----------------
$ROUTES = [
    ''                      => 'index.html',
    'index'                 => 'index.html',
    'domov'                 => 'index.html',
    'o-nas'                 => 'o-nás.html',
    'o-nás'                 => 'o-nás.html',
    'on-as'                 => 'o-nás.html',
    'zelena-podnikom'       => 'zelená-podnikom.html',
    'zelená-podnikom'       => 'zelená-podnikom.html',
    'projekty-samrs'        => 'projekty-samrs.html',
    'kontakt'               => 'kontakt.html',
    'mapa-webu'             => 'mapa-webu.html',
    'fotovoltika'           => 'fotovoltika.html',
    'solarny-ohrev'         => 'solárny-ohrev.html',
    'solárny-ohrev'         => 'solárny-ohrev.html',
    'orc-jednotky'          => 'orc-jednotky.html',
    'absorbecne-chladenie'  => 'absorpčné-chladenie.html',
    'absorpčné-chladenie'   => 'absorpčné-chladenie.html',
    'bateriove-uloziska'    => 'bateriové-úložiská.html',
    'bateriové-úložiská'    => 'bateriové-úložiská.html',
    'riesenia-na-kluc'      => 'riešenia-na-kľúč.html',
    'riešenia-na-kľúč'      => 'riešenia-na-kľúč.html',
    'servis'                => 'servis.html',
];

// ---------------- Presmerovania starých adries ----------------
$REDIRECTS = [
    'sluzby'  => 'riesenia-na-kluc',
    'služby'  => 'riesenia-na-kluc',
];

$LANGS = ['sk', 'en', 'an', 'de'];

// ---------------- Cesta z požiadavky ----------------
$requestUri  = (string)($_SERVER['REQUEST_URI'] ?? '/');

// ---------------- Healthcheck (Railway) ----------------
// Musí odpovedať skôr než presmerovania nižšie, inak by deploy neprešiel.
$healthPath = trim((string)(parse_url($requestUri, PHP_URL_PATH) ?: '/'), '/');
if ($healthPath === 'healthz') {
    http_response_code(200);
    header('Content-Type: text/plain; charset=UTF-8');
    header('Cache-Control: no-store, max-age=0');
    header('X-Robots-Tag: noindex, nofollow');
    header_remove('X-Powered-By');
    echo 'ok';
    exit;
}

// ---------------- Kanonická doména ----------------
// Jedna verzia webu pre vyhľadávače: https://www.elvosolar.sk (zhoduje sa s canonical).
$reqHost = strtolower((string)preg_replace('/:\d+$/', '', (string)($_SERVER['HTTP_HOST'] ?? '')));
if ($reqHost === 'elvosolar.sk') {
    header('Location: https://www.elvosolar.sk' . ($requestUri !== '' ? $requestUri : '/'), true, 301);
    exit;
}
// Náhľadové adresy Railway nesmú ísť do indexu (duplicitný obsah voči www.elvosolar.sk).
if ($reqHost !== '' && preg_match('/(^|\.)(up\.)?railway\.app$/', $reqHost)) {
    header('X-Robots-Tag: noindex, nofollow');
}
$requestPath = rawurldecode((string)(parse_url($requestUri, PHP_URL_PATH) ?: '/'));
$stripped    = trim($requestPath, '/');

// PHP vstavaný server (php -S web-router.php): existujúce súbory servíruj priamo
// (na Apache to isté robí .htaccess cez RewriteCond -f / -d).
if (PHP_SAPI === 'cli-server') {
    $candidate = __DIR__ . '/' . $stripped;
    if ($stripped !== '' && (is_file($candidate) || is_dir($candidate))) {
        return false;
    }
}

// ---------------- Jazykový prefix ----------------
$lang     = null;
$segments = $stripped === '' ? [] : explode('/', $stripped);
if ($segments && in_array(strtolower($segments[0]), $LANGS, true)) {
    $lang = strtolower(array_shift($segments));
    if ($lang === 'an') { $lang = 'en'; }
    $stripped = implode('/', $segments);
}

// ---------------- Presmerovanie ----------------
$redirectKey = strtolower($stripped);
if (isset($REDIRECTS[$redirectKey])) {
    $langPrefix = $lang !== null ? '/' . $lang : '';
    header('Location: ' . $langPrefix . '/' . $REDIRECTS[$redirectKey], true, 301);
    exit;
}

// ---------------- Vyriešenie trasy ----------------
$file = $ROUTES[$redirectKey] ?? null;
if ($file === null && $stripped !== '' && strpos($stripped, '/') === false) {
    $cand = $stripped . '.html';
    if (is_file(__DIR__ . '/' . $cand)) {
        $file = $cand;
    }
}

$isError = false;
if ($file === null || !is_file(__DIR__ . '/' . $file)) {
    $file    = '404.html';
    $isError = true;
}

// ---------------- Hlavičky ----------------
if ($isError) {
    http_response_code(404);
}
header('Content-Type: text/html; charset=UTF-8');
header_remove('X-Powered-By');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('X-Frame-Options: DENY');

// ---------------- Výstup ----------------
$html = (string)file_get_contents(__DIR__ . '/' . $file);

// Pri prefixovaných/čistých URL musia relatívne cesty (assets/…) smerovať od koreňa.
$prefix = '';
if ($lang !== null || strpos($stripped, '/') !== false) {
    $prefix .= '<base href="/">';
}
if ($lang !== null) {
    $prefix .= '<script>try{localStorage.setItem(\'elvo_lang\',\''
        . htmlspecialchars($lang, ENT_QUOTES, 'UTF-8')
        . '\')}catch(e){}</script>';
}
if ($prefix !== '') {
    $html = preg_replace('#<head([^>]*)>#i', '<head$1>' . $prefix, $html, 1);
}

echo $html;
